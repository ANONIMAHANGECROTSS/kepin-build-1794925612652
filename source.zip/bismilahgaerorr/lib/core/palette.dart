// KepinDumper design system: dark bento premium.
import 'package:flutter/material.dart';

const Color kBg = Color(0xFF06070A);
const Color kBgDeep = Color(0xFF040507);
const Color kSurface = Color(0xFF10131C);
const Color kSurface2 = Color(0xFF151A26);
const Color kSurfaceHi = Color(0xFF1C2231);
const Color kStroke = Color(0xFF1E2430);
const Color kStrokeHi = Color(0xFF2A3244);
const Color kLime = Color(0xFFC4FF4D);
const Color kLimeDim = Color(0xFF9BD137);
const Color kMint = Color(0xFF6FF2B1);
const Color kCoral = Color(0xFFFF6B6B);
const Color kAmber = Color(0xFFFFC94D);
const Color kText = Color(0xFFF2F5FA);
const Color kDim = Color(0xFF9AA3B2);
const Color kFaint = Color(0xFF5C6675);

const String kFontDisplay = 'SpaceGrotesk';
const String kFontMono = 'JetBrainsMono';

TextStyle kDisplay({double size = 26, FontWeight w = FontWeight.w700, Color c = kText, double ls = -0.5}) =>
    TextStyle(fontFamily: kFontDisplay, fontSize: size, fontWeight: w, color: c, letterSpacing: ls, height: 1.1);

TextStyle kMono({double size = 12, FontWeight w = FontWeight.w400, Color c = kDim, double ls = 0.2}) =>
    TextStyle(fontFamily: kFontMono, fontSize: size, fontWeight: w, color: c, letterSpacing: ls, height: 1.35);

TextStyle kBody({double size = 14, FontWeight w = FontWeight.w400, Color c = kText, double ls = 0}) =>
    TextStyle(fontSize: size, fontWeight: w, color: c, letterSpacing: ls, height: 1.45);

Duration kAnim = const Duration(milliseconds: 300);
Curve kCurve = Curves.easeOutCubic;

// ---- widgets ---------------------------------------------------------------

class KCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final double radius;
  final Color? border;
  const KCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.margin, this.radius = 22, this.border});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [kSurface, kSurface2],
        ),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: border ?? kStroke, width: 1),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: child,
    );
  }
}

class KTap extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double pressed;
  const KTap({super.key, required this.child, this.onTap, this.pressed = 0.97});
  @override
  State<KTap> createState() => _KTapState();
}

class _KTapState extends State<KTap> {
  bool _down = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) => setState(() => _down = false),
      onTapCancel: () => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? widget.pressed : 1.0,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
  }
}

class KChip extends StatelessWidget {
  final String text;
  final Color color;
  final bool filled;
  const KChip({super.key, required this.text, this.color = kDim, this.filled = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: filled ? color.withOpacity(0.16) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(filled ? 0.55 : 0.35), width: 1),
      ),
      child: Text(
        text,
        style: kMono(size: 10, w: FontWeight.w700, c: color, ls: 0.8),
      ),
    );
  }
}

class KBar extends StatelessWidget {
  final double value; // 0..1
  final double height;
  final Color color;
  final bool glow;
  const KBar({super.key, required this.value, this.height = 7, this.color = kLime, this.glow = true});

  @override
  Widget build(BuildContext context) {
    final v = value.clamp(0.0, 1.0);
    return ClipRRect(
      borderRadius: BorderRadius.circular(99),
      child: Container(
        height: height,
        decoration: BoxDecoration(
          color: kSurfaceHi,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Stack(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutCubic,
              width: (v <= 0 ? 0.001 : v) * (MediaQuery.of(context).size.width),
              height: height,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(99),
                boxShadow: glow ? [BoxShadow(color: color.withOpacity(0.45), blurRadius: 10)] : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class KPrimaryButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onTap;
  final bool enabled;
  final Color color;
  final Color textColor;
  const KPrimaryButton({
    super.key,
    required this.label,
    required this.icon,
    this.onTap,
    this.enabled = true,
    this.color = kLime,
    this.textColor = kBgDeep,
  });

  @override
  Widget build(BuildContext context) {
    final c = enabled ? color : kSurfaceHi;
    return KTap(
      onTap: enabled ? onTap : null,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 15),
        decoration: BoxDecoration(
          color: c,
          borderRadius: BorderRadius.circular(16),
          boxShadow: enabled
              ? [BoxShadow(color: color.withOpacity(0.35), blurRadius: 18, offset: const Offset(0, 6))]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 20, color: enabled ? textColor : kFaint),
            const SizedBox(width: 10),
            Text(
              label,
              style: kDisplay(size: 15, w: FontWeight.w700, c: enabled ? textColor : kFaint, ls: 1.2),
            ),
          ],
        ),
      ),
    );
  }
}

class KSectionLabel extends StatelessWidget {
  final String text;
  const KSectionLabel({super.key, required this.text});
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 4, height: 14, decoration: BoxDecoration(color: kLime, borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 8),
        Text(text, style: kMono(size: 11, w: FontWeight.w700, c: kDim, ls: 1.4)),
      ],
    );
  }
}

class KStatCell extends StatelessWidget {
  final String value;
  final String label;
  final Color color;
  const KStatCell({super.key, required this.value, required this.label, this.color = kText});
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value, style: kMono(size: 15, w: FontWeight.w700, c: color)),
        const SizedBox(height: 2),
        Text(label.toUpperCase(), style: kMono(size: 9, c: kFaint, ls: 1.2)),
      ],
    );
  }
}

/// Transisi halaman smooth (fade + slide halus).
Route<T> kFadeRoute<T>(Widget page, {Offset begin = const Offset(0, 0.03)}) {
  return PageRouteBuilder<T>(
    transitionDuration: kAnim,
    pageBuilder: (context, animation, secondary) => page,
    transitionsBuilder: (context, animation, secondary, child) {
      final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween(begin: begin, end: Offset.zero).animate(curved),
          child: ScaleTransition(scale: Tween(begin: 0.98, end: 1.0).animate(curved), child: child),
        ),
      );
    },
  );
}
