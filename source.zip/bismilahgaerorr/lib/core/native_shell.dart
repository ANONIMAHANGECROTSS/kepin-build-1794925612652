// KepinDumper: native bridge via root shell (su) — deteksi app foreground,
// pm path, ekstraksi file game. Semua best-effort dengan timeout.

import 'dart:async';
import 'dart:io';
import 'dart:convert';

class ShellResult {
  final int exit;
  final String out;
  final bool timedOut;
  const ShellResult(this.exit, this.out, this.timedOut);
  bool get ok => !timedOut && exit == 0;
}

class NativeShell {
  static const String ownPackage = 'com.kepin.dumper';

  /// Run command via su. Return stdout.
  static Future<ShellResult> su(String cmd, {int timeoutSec = 25}) async {
    try {
      final p = await Process.start('su', ['-c', cmd]);
      final out = StringBuffer();
      final timer = Timer(Duration(seconds: timeoutSec), () {
        try {
          p.kill();
        } catch (_) {}
      });
      final data = <int>[];
      final completer = Completer<void>();
      p.stdout.listen(data.addAll, onDone: () => completer.complete(), onError: (_) => completer.complete());
      await completer.future;
      final errData = <int>[];
      final errCompleter = Completer<void>();
      p.stderr.listen(errData.addAll, onDone: () => errCompleter.complete(), onError: (_) => errCompleter.complete());
      await errCompleter.future.timeout(const Duration(seconds: 3), onTimeout: () {});
      final code = await p.exitCode.timeout(Duration(seconds: timeoutSec), onTimeout: () => -9);
      timer.cancel();
      out.write(utf8.decode(data, allowMalformed: true));
      out.write(utf8.decode(errData, allowMalformed: true));
      return ShellResult(code, out.toString(), code == -9);
    } catch (e) {
      return ShellResult(-1, e.toString(), false);
    }
  }

  /// Cek root tersedia (su + uid=0).
  static Future<bool> hasRoot() async {
    final r = await su('id', timeoutSec: 8);
    return r.ok && r.out.contains('uid=0');
  }

  /// Paket aplikasi yang lagi foreground (root: dumpsys).
  static Future<String?> foregroundPackage() async {
    final cmds = [
      "dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'",
      "dumpsys window | grep -m1 -E 'mCurrentFocus|mFocusedApp'",
    ];
    for (final cmd in cmds) {
      final r = await su(cmd, timeoutSec: 10);
      if (r.out.isEmpty) continue;
      final m = RegExp(r'[{}]\s*([a-zA-Z][a-zA-Z0-9._]*)/').firstMatch(r.out);
      if (m != null) {
        final pkg = m.group(1) ?? '';
        if (pkg.isNotEmpty && pkg != ownPackage && pkg != 'com.android.systemui') {
          return pkg;
        }
      }
      final m2 = RegExp(r'([a-zA-Z][a-zA-Z0-9._]*)/[a-zA-Z][a-zA-Z0-9._]*\s').firstMatch(r.out);
      if (m2 != null) {
        final pkg = m2.group(1) ?? '';
        if (pkg.isNotEmpty && pkg != ownPackage && pkg != 'com.android.systemui') {
          return pkg;
        }
      }
    }
    return null;
  }

  /// Semua path APK dari paket (base + split).
  static Future<List<String>> apkPaths(String pkg) async {
    final r = await su('pm path $pkg', timeoutSec: 10);
    if (!r.ok) return const [];
    final paths = <String>[];
    for (final line in r.out.split('\n')) {
      final l = line.trim();
      if (l.startsWith('package:')) {
        final p = l.substring(8).trim();
        if (p.isNotEmpty) paths.add(p);
      }
    }
    return paths;
  }

  /// Ekstrak anggota ZIP dari APK via root (unzip -p > out).
  static Future<bool> rootUnzipMember(String apk, String entry, String destOut) async {
    final r = await su("unzip -p '$apk' '$entry' > '$destOut'", timeoutSec: 120);
    if (!r.ok) return false;
    try {
      final f = File(destOut);
      return f.existsSync() && f.lengthSync() > 64;
    } catch (_) {
      return false;
    }
  }

  /// Copy file (root) ke tujuan.
  static Future<bool> rootCopy(String src, String dest) async {
    final r = await su("cp '$src' '$dest' && chmod 644 '$dest' && ls -la '$dest'", timeoutSec: 300);
    return r.ok;
  }
}
