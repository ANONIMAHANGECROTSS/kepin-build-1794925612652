// KepinDumper: page FLOAT — start overlay dumper (drag di atas game).

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import '../core/palette.dart';
import '../core/native_shell.dart';

class FloatPage extends StatefulWidget {
  const FloatPage({super.key});
  @override
  State<FloatPage> createState() => _FloatPageState();
}

class _FloatPageState extends State<FloatPage> {
  bool _overlayOk = false;
  bool _rootOk = false;
  bool _checking = true;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    setState(() => _checking = true);
    bool ov = false;
    try {
      ov = await FlutterOverlayWindow.isPermissionGranted();
    } catch (_) {}
    bool root = false;
    try {
      root = await NativeShell.hasRoot();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _overlayOk = ov;
      _rootOk = root;
      _checking = false;
    });
  }

  Future<void> _requestOverlay() async {
    try {
      final ok = await FlutterOverlayWindow.requestPermission();
      if (mounted) {
        setState(() => _overlayOk = ok ?? false);
      }
    } catch (_) {}
  }

  Future<void> _start() async {
    if (!_overlayOk) {
      await _requestOverlay();
      if (!_overlayOk) {
        _toast('Izin overlay belum diberikan');
        return;
      }
    }
    try {
      await FlutterOverlayWindow.showOverlay(
        height: 236,
        width: 320,
        alignment: OverlayAlignment.center,
        enableDrag: true,
        positionGravity: PositionGravity.auto,
        overlayTitle: 'KepinDumper',
        overlayContent: 'Floating dumper aktif',
      );
    } catch (e) {
      _toast('Overlay gagal: $e');
      return;
    }
    // keluar dari aplikasi → overlay melayang
    await Future.delayed(const Duration(milliseconds: 350));
    SystemNavigator.pop();
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      behavior: SnackBarBehavior.floating,
      backgroundColor: kSurfaceHi,
      content: Text(msg, style: kMono(size: 11, c: kText)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: kStroke)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 118),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('FLOAT', style: kDisplay(size: 26, w: FontWeight.w700, c: kText, ls: 1.4)),
                  Text('MODE MELAYANG — DUMP GAME LANGSUNG', style: kMono(size: 9, c: kFaint, ls: 1.8)),
                ],
              ),
              const Spacer(),
              const KChip(text: 'OVERLAY', color: kLimeDim),
            ],
          ),
          const SizedBox(height: 16),
          // hero card
          KCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: kLime.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: kLime.withOpacity(0.4)),
                      ),
                      child: const Icon(Icons.picture_in_picture_alt_rounded, color: kLime, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('KEPIN DUMPER FLOAT', style: kDisplay(size: 15, w: FontWeight.w700, c: kText, ls: 0.8)),
                          const SizedBox(height: 2),
                          Text('bisa di-drag di atas game', style: kMono(size: 10, c: kFaint)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _step('1', 'Tekan START — app ke-minimize, GUI melayang muncul'),
                const SizedBox(height: 8),
                _step('2', 'Buka game — paketnya kebaca otomatis di GUI'),
                const SizedBox(height: 8),
                _step('3', 'Tekan DUMP — engine il2cpp jalan, hasil ke KepinDumper/<paket>'),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // status izin
          KCard(
            child: Column(
              children: [
                _statusRow(
                  icon: Icons.layers_outlined,
                  title: 'Izin Overlay',
                  ok: _overlayOk,
                  action: !_overlayOk ? 'IZINKAN' : null,
                  onTap: _requestOverlay,
                ),
                const Divider(color: kStroke, height: 22),
                _statusRow(
                  icon: Icons.terminal_rounded,
                  title: 'Root (su)',
                  ok: _rootOk,
                  hint: 'butuh root buat baca APK game',
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // start
          KCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const KSectionLabel(text: 'MULAI'),
                const SizedBox(height: 12),
                if (_checking)
                  const Center(child: SizedBox(width: 160, child: KBar(value: 0.4)))
                else
                  KPrimaryButton(
                    label: 'START FLOAT',
                    icon: Icons.open_in_new_rounded,
                    onTap: _start,
                    enabled: _overlayOk,
                  ),
                const SizedBox(height: 12),
                Text(
                  _rootOk
                      ? 'Output: /storage/emulated/0/KepinDumper/<paket_game>/'
                      : 'Root belum terdeteksi — FLOAT butuh su (kayak dumper GUI lain). UPLOAD mode tetap jalan tanpa root.',
                  style: kMono(size: 10, c: _rootOk ? kLimeDim : kAmber),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          KTap(
            onTap: _check,
            child: Center(child: Text('↻ CEK LAGI', style: kMono(size: 11, w: FontWeight.w700, c: kDim, ls: 1.6))),
          ),
        ],
      ),
    );
  }

  Widget _step(String n, String text) {
    return Row(
      children: [
        Container(
          width: 22,
          height: 22,
          decoration: BoxDecoration(color: kSurfaceHi, borderRadius: BorderRadius.circular(7)),
          child: Center(child: Text(n, style: kMono(size: 10, w: FontWeight.w700, c: kLime))),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(text, style: kBody(size: 12, c: kDim))),
      ],
    );
  }

  Widget _statusRow({
    required IconData icon,
    required String title,
    required bool ok,
    String? action,
    VoidCallback? onTap,
    String? hint,
  }) {
    return Row(
      children: [
        Icon(icon, color: ok ? kMint : kCoral, size: 18),
        const SizedBox(width: 12),
        Expanded(
          child: Text(title, style: kBody(size: 13, w: FontWeight.w700, c: kText)),
        ),
        if (hint != null && !ok) ...[
          const SizedBox(width: 8),
          Flexible(child: Text(hint, style: kMono(size: 9, c: kFaint), overflow: TextOverflow.ellipsis)),
        ],
        if (action != null) ...[
          const SizedBox(width: 8),
          KTap(
            onTap: onTap,
            child: KChip(text: action, color: kLime, filled: true),
          ),
        ] else ...[
          KChip(text: ok ? 'OK' : 'GAK ADA', color: ok ? kMint : kCoral),
        ],
      ],
    );
  }
}
