// KepinDumper: page UPLOAD — bento grid, picker / path manual, dump + progress.

import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../core/palette.dart';
import '../core/dump_runner.dart';

class _PickState {
  String? path;
  int size = 0;
  bool valid = false;
  String? note;
  String get label {
    if (path == null) return '—';
    final f = File(path!);
    return f.uri.pathSegments.isNotEmpty ? f.uri.pathSegments.last : path!;
  }
}

class UploadPage extends StatefulWidget {
  const UploadPage({super.key});
  @override
  State<UploadPage> createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  final _soController = TextEditingController();
  final _mdController = TextEditingController();
  final _outBase = '/storage/emulated/0/KepinDumper';
  _PickState _so = _PickState();
  _PickState _md = _PickState();
  bool _running = false;
  double _pct = 0;
  String _phase = '';
  String _detail = '';
  Map<String, dynamic>? _result;
  bool _failed = false;
  String _errMsg = '';

  @override
  void dispose() {
    _soController.dispose();
    _mdController.dispose();
    super.dispose();
  }

  Future<void> _pick(bool isSo) async {
    try {
      final res = await FilePicker.platform.pickFiles(type: FileType.any);
      final files = res?.files;
      if (files == null || files.isEmpty) return;
      final f = files.first;
      final p = f.path;
      if (p == null) return;
      await _setPath(isSo, p);
    } catch (_) {}
  }

  Future<void> _setPath(bool isSo, String p) async {
    final st = _PickState();
    st.path = p;
    try {
      final file = File(p);
      st.size = await file.length();
      final head = await file.open();
      await head.setPosition(0);
      final b = await head.read(4);
      await head.close();
      if (isSo) {
        st.valid = b.length >= 4 && b[0] == 0x7F && b[1] == 0x45 && b[2] == 0x4C && b[3] == 0x46;
        st.note = st.valid ? 'ELF VALID' : 'BUKAN ELF';
      } else {
        st.valid = b.length >= 4 && b[0] == 0xAF && b[1] == 0x1B && b[2] == 0xB1 && b[3] == 0xFA;
        st.note = st.valid ? 'METADATA VALID' : 'MAGIC SALAH';
        if (st.valid) {
          try {
            final h = await File(p).open();
            await h.setPosition(4);
            final v = await h.read(4);
            await h.close();
            final ver = ByteData.sublistView(v).getInt32(0, Endian.little);
            st.note = 'METADATA v$ver';
          } catch (_) {}
        }
      }
    } catch (e) {
      st.note = 'GAK KEBACA';
    }
    setState(() {
      if (isSo) {
        _so = st;
        _soController.text = p;
      } else {
        _md = st;
        _mdController.text = p;
      }
    });
  }

  Future<void> _dump() async {
    final soPath = _soController.text.trim().isNotEmpty ? _soController.text.trim() : _so.path;
    final mdPath = _mdController.text.trim().isNotEmpty ? _mdController.text.trim() : _md.path;
    if (soPath == null || soPath.isEmpty) {
      _toast('Pilih / isi path libil2cpp.so dulu');
      return;
    }
    if (mdPath == null || mdPath.isEmpty) {
      _toast('Pilih / isi path global-metadata.dat dulu');
      return;
    }
    if (!File(soPath).existsSync() || !File(mdPath).existsSync()) {
      _toast('File gak ketemu — cek pathnya');
      return;
    }
    final ts = DateTime.now();
    final stamp = '${ts.year}${_two(ts.month)}${_two(ts.day)}_${_two(ts.hour)}${_two(ts.minute)}${_two(ts.second)}';
    final outDir = '$_outBase/upload_$stamp';
    setState(() {
      _running = true;
      _failed = false;
      _result = null;
      _pct = 0;
      _phase = 'mulai';
      _detail = '';
    });
    final res = await DumpRunner.start(
      il2cppPath: soPath,
      metadataPath: mdPath,
      outDir: outDir,
      onProgress: (m) {
        if (mounted) {
          setState(() {
            _pct = m.pct / 100;
            _phase = m.phase;
            _detail = m.detail;
          });
        }
      },
    );
    if (mounted) {
      setState(() {
        _running = false;
        if (res['ok'] == true) {
          _result = (res['stats'] as Map).cast<String, dynamic>();
        } else {
          _failed = true;
          _errMsg = (res['error'] ?? 'unknown').toString();
        }
      });
    }
  }

  String _two(int n) => n.toString().padLeft(2, '0');

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      behavior: SnackBarBehavior.floating,
      backgroundColor: kSurfaceHi,
      content: Text(msg, style: kMono(size: 11, c: kText)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: kStroke)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 118),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // header
          Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('UPLOAD', style: kDisplay(size: 26, w: FontWeight.w700, c: kText, ls: 1.4)),
                  Text('MODE MANUAL — BAWA FILE SENDIRI', style: kMono(size: 9, c: kFaint, ls: 1.8)),
                ],
              ),
              const Spacer(),
              const KChip(text: 'ENGINE v3', color: kLimeDim),
            ],
          ),
          const SizedBox(height: 16),
          // bento row 1: dua file
          Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(child: _fileCard(isSo: true)),
              const SizedBox(width: 12),
              Expanded(child: _fileCard(isSo: false)),
            ],
          ),
          const SizedBox(height: 12),
          // path manual
          _pathsCard(),
          const SizedBox(height: 12),
          // dump / progress / hasil
          if (!_running && _result == null && !_failed) _dumpCard(),
          if (_running) _progressCard(),
          if (_result != null) _resultCard(),
          if (_failed) _errorCard(),
          const SizedBox(height: 10),
          if (_result != null || _failed)
            KTap(
              onTap: () => setState(() {
                _result = null;
                _failed = false;
              }),
              child: Center(
                child: Text('← DUMP LAGI', style: kMono(size: 11, w: FontWeight.w700, c: kDim, ls: 1.6)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _fileCard({required bool isSo}) {
    final st = isSo ? _so : _md;
    final ok = st.valid;
    return KTap(
      onTap: () => _pick(isSo),
      child: KCard(
        border: ok ? kLime.withOpacity(0.35) : kStroke,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: kSurfaceHi,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: ok ? kLime.withOpacity(0.4) : kStroke),
                  ),
                  child: Icon(
                    isSo ? Icons.memory_outlined : Icons.dataset_outlined,
                    color: ok ? kLime : kDim,
                    size: 18,
                  ),
                ),
                const Spacer(),
                if (st.path != null)
                  KChip(text: st.note ?? '', color: ok ? kMint : kCoral, filled: true)
                else
                  const KChip(text: 'PILIH', color: kFaint),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              isSo ? 'libil2cpp.so' : 'global-metadata.dat',
              style: kMono(size: 12, w: FontWeight.w700, c: kText),
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              st.path == null
                  ? 'tap buat pilih file'
                  : '${(st.size / 1024 / 1024).toStringAsFixed(1)} MB',
              style: kMono(size: 10, c: kFaint),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _pathsCard() {
    return KCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const KSectionLabel(text: 'PATH MANUAL (OPSIONAL)'),
          const SizedBox(height: 12),
          _field(controller: _soController, hint: '/storage/emulated/0/.../libil2cpp.so'),
          const SizedBox(height: 8),
          _field(controller: _mdController, hint: '/storage/emulated/0/.../global-metadata.dat'),
        ],
      ),
    );
  }

  Widget _field({required TextEditingController controller, required String hint}) {
    return TextField(
      controller: controller,
      style: kMono(size: 11, c: kText),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: kMono(size: 10, c: kFaint),
        filled: true,
        fillColor: kBgDeep,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: kStroke),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: kLime, width: 1.2),
        ),
      ),
    );
  }

  Widget _dumpCard() {
    return KCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const KSectionLabel(text: 'ENGINE DUMP'),
          const SizedBox(height: 12),
          Text('Parse ELF + global-metadata → dump.cs, stringliteral.txt, script.json, info.txt',
              style: kMono(size: 10, c: kFaint)),
          const SizedBox(height: 6),
          Text('Output: $_outBase/<stamp>/', style: kMono(size: 10, c: kLimeDim)),
          const SizedBox(height: 14),
          KPrimaryButton(label: 'DUMP SEKARANG', icon: Icons.bolt_rounded, onTap: _dump),
        ],
      ),
    );
  }

  Widget _progressCard() {
    return KCard(
      child: Column(
        children: [
          Row(
            children: [
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(color: kLime, strokeWidth: 2),
              ),
              const SizedBox(width: 12),
              Text('RUNNING', style: kMono(size: 11, w: FontWeight.w700, c: kLime, ls: 1.6)),
              const Spacer(),
              Text('${(_pct * 100).toStringAsFixed(0)}%', style: kMono(size: 13, w: FontWeight.w700, c: kText)),
            ],
          ),
          const SizedBox(height: 10),
          Text(_detail.isEmpty ? '...' : _detail, style: kMono(size: 10, c: kDim), overflow: TextOverflow.ellipsis),
          const SizedBox(height: 12),
          KBar(value: _pct),
        ],
      ),
    );
  }

  Widget _resultCard() {
    final s = _result;
    if (s == null) return const SizedBox.shrink();
    final ok = s['methodsWithRva'] != null && (s['methodsWithRva'] as int) > 0;
    return KCard(
      border: kMint.withOpacity(0.35),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.check_circle_rounded, color: kMint, size: 18),
              const SizedBox(width: 10),
              Text('DUMP BERES', style: kDisplay(size: 14, w: FontWeight.w700, c: kMint, ls: 1.2)),
              const Spacer(),
              KChip(text: 'il2cpp v${s['il2cppVersion']}', color: kLimeDim),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              KStatCell(value: _fmtNum(s['typeCount'] as int? ?? 0), label: 'tipe', color: kText),
              KStatCell(value: _fmtNum(s['methodCount'] as int? ?? 0), label: 'method', color: kText),
              KStatCell(value: _fmtNum(s['fieldCount'] as int? ?? 0), label: 'field', color: kText),
              KStatCell(
                value: ok ? _fmtNum(s['methodsWithRva'] as int) : '0',
                label: 'rva',
                color: kLime,
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: kBgDeep, borderRadius: BorderRadius.circular(12)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('OUTPUT', style: kMono(size: 9, c: kFaint, ls: 1.6)),
                const SizedBox(height: 4),
                Text(
                  '${s['metadataVersion'] != null ? 'metadata v${s['metadataVersion']} · ' : ''}'
                  '${_fmtNum(s['stringLiteralCount'] as int? ?? 0)} string literal',
                  style: kMono(size: 10, c: kDim),
                ),
                const SizedBox(height: 6),
                Text('/storage/emulated/0/KepinDumper/', style: kMono(size: 10, c: kMint)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _errorCard() {
    return KCard(
      border: kCoral.withOpacity(0.4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.error_outline_rounded, color: kCoral, size: 18),
              const SizedBox(width: 10),
              Text('DUMP GAGAL', style: kDisplay(size: 14, w: FontWeight.w700, c: kCoral, ls: 1.2)),
            ],
          ),
          const SizedBox(height: 10),
          Text(_errMsg, style: kMono(size: 10, c: kDim)),
        ],
      ),
    );
  }
}

String _fmtNum(int n) {
  if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
  if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}rb';
  return '$n';
}
