// KepinDumper engine: Il2Cpp registration discovery + runtime tables.
// Faithful port of Il2CppDumper's SectionHelper search, AutoPlusInit version
// refinement and Init() table loading, tuned with an array-walk shortcut so
// huge binaries don't need hundreds of full data scans.

import 'dart:typed_data';
import 'elf.dart';
import 'metadata.dart';

class CodeGenModule {
  final String name;
  final int methodPointerCount;
  final Uint32List methodPointers; // vaddr list (rid-1 indexed)
  CodeGenModule(this.name, this.methodPointerCount, this.methodPointers);
}

class Il2CppTypeEntry {
  final int data; // union value (index / pointer / rank etc)
  final int bits;
  const Il2CppTypeEntry(this.data, this.bits);
}

class Il2CppBin {
  final ElfImage elf;
  final Metadata meta;
  double version = 0;
  bool versionChanged = false;
  int get ptrSize => elf.pointerSize;

  // CodeRegistration (slot = 8 bytes; pair count+ptr = 2 slot)
  int codeRegAddr = 0;
  int rpiCount = 0;
  int gmpCount = 0;
  int interopDataCount = 0;
  int invCount = 0;
  int gmpPtr = 0;
  int cgmCount = 0;
  int cgmPtr = 0;

  // MetadataRegistration
  int metaRegAddr = 0;
  int genericInstsCount = 0;
  int genericInstsPtr = 0;
  int genericMethodTableCount = 0;
  int genericMethodTablePtr = 0;
  int typesCount = 0;
  int typesPtr = 0;
  int methodSpecsCount = 0;
  int methodSpecsPtr = 0;
  int fieldOffsetsCount = 0;
  int fieldOffsetsPtr = 0;

  // tables
  final Map<String, CodeGenModule> codeGenModules = {};
  final Map<int, Il2CppTypeEntry> _typeByPtr = {};
  Uint32List typePtrs = Uint32List(0);
  List<Il2CppTypeEntry> types = const [];
  Uint32List fieldOffsetPtrs = Uint32List(0);
  Uint32List genericMethodPointers = Uint32List(0);
  Uint32List genericInstPtrs = Uint32List(0);
  Uint32List globalMethodPointers = Uint32List(0);
  final Map<int, List<int>> methodDefinitionMethodSpecs = {};
  Uint32List _specPtrs = Uint32List(0);
  Int32List specMd = Int32List(0); // per methodSpec: methodDefinitionIndex
  Int32List specClass = Int32List(0); // classIndexIndex (generic inst)
  Int32List specMethod = Int32List(0); // methodIndexIndex (generic inst)
  bool hasRegistrations = false;
  String searchLog = '';

  Il2CppBin(this.elf, this.meta) {
    version = meta.version;
  }

  // ---------------------------------------------------------------- helpers

  static int _u64(Uint8List b, int o) =>
      b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24) |
      (b[o + 4] << 32) | (b[o + 5] << 40) | (b[o + 6] << 48) | (b[o + 7] << 56);

  static int _u32(Uint8List b, int o) =>
      b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24);

  /// Baca array pointer (vaddr, < 2^32 buat .so Android) pada VA tertentu.
  Uint32List _readVaArray(int va, int count) {
    if (va == 0 || count <= 0 || count > 6000000) return Uint32List(0);
    final fileOff = elf.mapVATR(va);
    if (fileOff == 0 || fileOff + count * ptrSize > elf.file.length) return Uint32List(0);
    final buff = elf.file.readBytes(fileOff, count * ptrSize);
    final out = Uint32List(count);
    if (ptrSize == 8) {
      for (int i = 0; i < count; i++) {
        out[i] = _u64(buff, i * 8) & 0xFFFFFFFF;
      }
    } else {
      for (int i = 0; i < count; i++) {
        out[i] = _u32(buff, i * 4);
      }
    }
    return out;
  }

  bool _ptrInDataFile(int fileOff) {
    for (final s in elf.dataSections) {
      if (fileOff >= s.offset && fileOff <= s.offsetEnd) return true;
    }
    return false;
  }

  bool _ptrsInExecVa(Iterable<int> vaList) {
    for (final v in vaList) {
      bool ok = false;
      for (final s in elf.execSections) {
        if (v >= s.address && v <= s.addressEnd) {
          ok = true;
          break;
        }
      }
      if (!ok) return false;
    }
    return true;
  }

  bool _ptrsInDataVa(Iterable<int> vaList) {
    for (final v in vaList) {
      bool ok = false;
      for (final s in elf.dataSections) {
        if (v >= s.address && v <= s.addressEnd) {
          ok = true;
          break;
        }
      }
      if (!ok) return false;
    }
    return true;
  }

  // ---------------------------------------------------------------- searching

  static const List<int> _mscorlibPattern = [
    0x6D, 0x73, 0x63, 0x6F, 0x72, 0x6C, 0x69, 0x62, 0x2E, 0x64, 0x6C, 0x6C, 0x00
  ]; // "mscorlib.dll\0"

  /// FindMetadataRegistrationV21 (v27+): cari [fieldOffsetsCount==TDC][ptr]
  /// [typeDefSizesCount==TDC][typeDefSizes ptr -> array TDC ptr di data],
  /// return posisi - 10 slot.
  int _findMetadataRegistrationV21() {
    final tdc = meta.typeDefCount;
    final ps = ptrSize;
    for (final sec in elf.dataSections) {
      final end = (sec.offsetEnd < elf.file.length ? sec.offsetEnd : elf.file.length) - ps;
      int pos = sec.offset;
      while (pos < end) {
        final addr = pos;
        if (elf.file.ptrAt(addr) == tdc) {
          if (elf.file.ptrAt(addr + ps * 2) == tdc) {
            try {
              final ptrVa = elf.file.ptrAt(addr + ps * 3);
              final fileOff = elf.mapVATR(ptrVa);
              if (fileOff != 0 && _ptrInDataFile(fileOff)) {
                final pointers = _readVaArray(ptrVa, tdc);
                if (pointers.length == tdc && _ptrsInDataVa(pointers)) {
                  return addr - ps * 10 - sec.offset + sec.address;
                }
              }
            } catch (_) {}
          }
        }
        pos += ps;
      }
    }
    return 0;
  }

  /// FindMetadataRegistrationOld (v24-26): [typeDefSizesCount==TDC] lalu
  /// pointer metadataUsages (di +3 slot) -> array pointer di bss/data.
  int _findMetadataRegistrationOld(int metadataUsagesCount) {
    final tdc = meta.typeDefCount;
    final ps = ptrSize;
    for (final sec in elf.dataSections) {
      final end = (sec.offsetEnd < elf.file.length ? sec.offsetEnd : elf.file.length) - ps;
      int pos = sec.offset;
      while (pos < end) {
        final addr = pos;
        if (elf.file.ptrAt(addr) == tdc) {
          try {
            final ptrVa = elf.file.ptrAt(addr + ps * 3);
            final fileOff = elf.mapVATR(ptrVa);
            if (fileOff != 0 && _ptrInDataFile(fileOff)) {
              final pointers = _readVaArray(ptrVa, metadataUsagesCount);
              if (_ptrsInDataVa(pointers)) {
                return addr - ps * 12 - sec.offset + sec.address;
              }
            }
          } catch (_) {}
        }
        pos += ps;
      }
    }
    return 0;
  }

  /// FindCodeRegistrationOld (v24.0-24.1): [methodPointersCount==methodCount][ptr]
  int _findCodeRegistrationOld(int methodCount) {
    final ps = ptrSize;
    for (final sec in elf.dataSections) {
      final end = (sec.offsetEnd < elf.file.length ? sec.offsetEnd : elf.file.length) - ps;
      int pos = sec.offset;
      while (pos < end) {
        final addr = pos;
        if (elf.file.ptrAt(addr) == methodCount) {
          try {
            final ptrVa = elf.file.ptrAt(addr + ps);
            final fileOff = elf.mapVATR(ptrVa);
            if (fileOff != 0 && _ptrInDataFile(fileOff)) {
              final pointers = _readVaArray(ptrVa, methodCount);
              if (pointers.length == methodCount && _ptrsInExecVa(pointers)) {
                return addr - sec.offset + sec.address;
              }
            }
          } catch (_) {}
        }
        pos += ps;
      }
    }
    return 0;
  }

  /// FindCodeRegistration2019 (v24.2+): string "mscorlib.dll" -> slot moduleName
  /// -> slot elemen array codegen modules -> base array -> &codeGenModules
  /// (+count di slot sebelumnya) -> start struct CodeRegistration.
  int _findCodeRegistration2019(bool execFirst) {
    for (final sec in (execFirst ? elf.execSections : elf.dataSections)) {
      int from = sec.offset;
      while (true) {
        final idx = elf.searchBytes(_mscorlibPattern, from, sec.offsetEnd);
        if (idx < 0) break;
        final dllva = idx + sec.address;
        for (final refva in elf.findReferences(dllva)) {
          for (final refva2 in elf.findReferences(refva)) {
            final result = _resolveCodeGenArrayStart(refva2);
            if (result != 0) return result;
          }
        }
        from = idx + 1;
        if (from >= sec.offsetEnd) break;
      }
    }
    return 0;
  }

  /// Diketahui VA elemen array codegen modules. Jalan mundur buat nemu base
  /// array (slot tetangga masih nunjuk struct module valid), lalu cari slot
  /// yang nunjuk base array + validasi [slot-1] == imageCount. Hasil: VA start
  /// struct CodeRegistration (persis chain FindReference referensi).
  int _resolveCodeGenArrayStart(int moduleSlot) {
    final ps = ptrSize;
    final imageCount = meta.imageDefCount;
    final slotFile = elf.mapVATR(moduleSlot);
    if (slotFile == 0) return 0;
    int back = slotFile;
    int guard = 0;
    while (guard < 2048) {
      final prev = back - ps;
      if (prev < 0) break;
      final val = elf.file.ptrAt(prev);
      final valOff = elf.mapVATR(val);
      if (valOff == 0) break;
      final name = elf.file.readCString(valOff, 256);
      if (!name.endsWith('.dll') || name.length < 5) break;
      back = prev;
      guard++;
    }
    final arrayStartVa = elf.mapRTVA(back);
    if (arrayStartVa == 0) return 0;
    for (final slot in elf.findReferences(arrayStartVa)) {
      final before = elf.mapVATR(slot - ps);
      if (before == 0) continue;
      if (elf.file.ptrAt(before) == imageCount) {
        if (version >= 29) return slot - ps * 14;
        return slot - ps * 13;
      }
    }
    return 0;
  }

  // ---------------------------------------------------------------- search high level

  bool symbolSearch() {
    final cr = elf.symbolValue('g_CodeRegistration');
    final mr = elf.symbolValue('g_MetadataRegistration');
    if (cr > 0 && mr > 0) {
      searchLog += 'Registrasi via symbol (g_CodeRegistration / g_MetadataRegistration).\n';
      codeRegAddr = cr;
      metaRegAddr = mr;
      return true;
    }
    return false;
  }

  bool plusSearch() {
    final methodCount = _methodCountForSearch();
    int cr = 0;
    bool pointerInExec = false;
    if (version >= 24.2) {
      cr = _findCodeRegistration2019(true);
      if (cr == 0) {
        cr = _findCodeRegistration2019(false);
      } else {
        pointerInExec = true;
      }
    } else {
      cr = _findCodeRegistrationOld(methodCount);
    }
    int mr = 0;
    if (version >= 27) {
      mr = _findMetadataRegistrationV21();
    } else {
      mr = _findMetadataRegistrationOld(_metadataUsagesCountForSearch());
    }
    if (cr != 0 && mr != 0) {
      searchLog += pointerInExec
          ? 'CodeRegistration ketemu via exec segment.\n'
          : 'CodeRegistration ketemu via data segment.\n';
      codeRegAddr = cr;
      metaRegAddr = mr;
      return true;
    }
    searchLog += 'CodeRegistration: 0x${cr.toRadixString(16)} | MetadataRegistration: 0x${mr.toRadixString(16)}\n';
    return false;
  }

  int _methodCountForSearch() {
    if (version <= 24.1) {
      int n = 0;
      for (int i = 0; i < meta.methodDefCount; i++) {
        if (meta.mdMethodIndex[i] >= 0) n++;
      }
      return n;
    }
    return meta.methodDefCount;
  }

  int _metadataUsagesCountForSearch() {
    if (version > 24.5) return 1;
    int max = 0;
    for (final d in meta.metadataUsageDestIndices) {
      if (d > max) max = d;
    }
    return max + 1;
  }

  // ---------------------------------------------------------------- AutoPlusInit + Init

  void _readCodeRegFields(int addr) {
    final v = version;
    final ps = ptrSize;
    final base = elf.mapVATR(addr);
    if (base == 0) return;
    int read(int slot) => elf.file.ptrAt(base + slot * ps);
    int o = 0;
    if (v <= 24.1) o += 2; // [Max=24.1] methodPointersCount + methodPointers (pair awal)
    if (v >= 22) {
      rpiCount = read(o);
      o += 2;
    }
    gmpCount = read(o);
    gmpPtr = read(o + 1);
    o += 2;
    if (v == 24.5 || v >= 27.1) o += 1; // genericAdjustorThunks
    invCount = read(o);
    o += 2;
    if (v <= 24.5) o += 2; // customAttributeCount + customAttributeGenerators
    if (v >= 22) o += 2; // unresolvedVirtualCall pair
    if (v >= 29.1) o += 2; // unresolvedInstanceCall + unresolvedStaticCall pointers
    if (v >= 23) {
      interopDataCount = read(o);
      o += 2;
    }
    if (v >= 24.3) o += 2; // windowsRuntimeFactory pair
    if (v >= 24.2) {
      cgmCount = read(o);
      cgmPtr = read(o + 1);
    }
  }

  bool autoPlusInit() {
    var codeRegistration = codeRegAddr;
    final metadataRegistration = metaRegAddr;
    const limit = 0x50000;
    final ps = ptrSize;
    if (codeRegistration == 0 || metadataRegistration == 0) return false;
    if (version >= 24.2) {
      _readCodeRegFields(codeRegistration);
      if (version == 31) {
        if (gmpCount > limit) {
          codeRegistration -= ps * 2;
        } else {
          version = 29;
          versionChanged = true;
        }
      }
      if (version == 29) {
        if (gmpCount > limit) {
          version = 29.1;
          codeRegistration -= ps * 2;
          versionChanged = true;
        }
      }
      if (version == 27) {
        if (rpiCount > limit) {
          version = 27.1;
          codeRegistration -= ps;
          versionChanged = true;
        }
      }
      if (version == 24.4) {
        codeRegistration -= ps * 2;
        if (rpiCount > limit) {
          version = 24.5;
          codeRegistration -= ps;
          versionChanged = true;
        }
      }
      if (version == 24.2) {
        if (interopDataCount == 0) {
          version = 24.3;
          codeRegistration -= ps * 2;
          versionChanged = true;
        }
      }
    }
    codeRegAddr = codeRegistration;
    _init();
    return true;
  }

  void _init() {
    const limit = 0x50000;
    final ps = ptrSize;
    _readCodeRegFields(codeRegAddr);
    if (version == 27 && invCount > limit) {
      version = 27.1;
      versionChanged = true;
      _readCodeRegFields(codeRegAddr);
    }
    if (version == 27.1) {
      // cek rgctx buat deteksi 27.2
      final mods = _readVaArray(cgmPtr, cgmCount);
      if (mods.isNotEmpty) {
        final modOff = elf.mapVATR(mods[0]);
        if (modOff != 0) {
          final rgctxsCount = elf.file.ptrAt(modOff + ps * 10);
          if (rgctxsCount > 0 && rgctxsCount < 4000000) {
            final rgctxsPtr = elf.file.ptrAt(modOff + ps * 11);
            final rgOff = elf.mapVATR(rgctxsPtr);
            if (rgOff != 0) {
              bool allBig = true;
              final n = rgctxsCount < 32 ? rgctxsCount : 32;
              for (int i = 0; i < n; i++) {
                final d = elf.file.ptrAt(rgOff + i * 16 + 8);
                if (d <= limit) {
                  allBig = false;
                  break;
                }
              }
              if (allBig) {
                version = 27.2;
                versionChanged = true;
              }
            }
          }
        }
      }
    }
    if (version == 24.4 && invCount > limit) {
      version = 24.5;
      versionChanged = true;
      _readCodeRegFields(codeRegAddr);
    }
    if (version == 24.2 && cgmPtr == 0) {
      version = 24.3;
      versionChanged = true;
      _readCodeRegFields(codeRegAddr);
    }

    // MetadataRegistration: pair k = count @ slot 2k, ptr @ slot 2k+1
    final mrBase = elf.mapVATR(metaRegAddr);
    genericInstsCount = elf.file.ptrAt(mrBase + ps * 2);
    genericInstsPtr = elf.file.ptrAt(mrBase + ps * 3);
    genericMethodTableCount = elf.file.ptrAt(mrBase + ps * 4);
    genericMethodTablePtr = elf.file.ptrAt(mrBase + ps * 5);
    typesCount = elf.file.ptrAt(mrBase + ps * 6);
    typesPtr = elf.file.ptrAt(mrBase + ps * 7);
    methodSpecsCount = elf.file.ptrAt(mrBase + ps * 8);
    methodSpecsPtr = elf.file.ptrAt(mrBase + ps * 9);
    fieldOffsetsCount = elf.file.ptrAt(mrBase + ps * 10);
    fieldOffsetsPtr = elf.file.ptrAt(mrBase + ps * 11);

    genericMethodPointers = _readVaArray(gmpPtr, gmpCount);
    genericInstPtrs = _readVaArray(genericInstsPtr, genericInstsCount);

    if (fieldOffsetsCount == meta.typeDefCount) {
      fieldOffsetPtrs = _readVaArray(fieldOffsetsPtr, fieldOffsetsCount);
    } else {
      fieldOffsetPtrs = Uint32List(0);
    }

    // types table
    typePtrs = _readVaArray(typesPtr, typesCount);
    types = const [];
    _typeByPtr.clear();
    if (typesCount > 0 && typesCount < 16000000 && typePtrs.length == typesCount) {
      final list = List<Il2CppTypeEntry>.filled(typesCount, const Il2CppTypeEntry(0, 0));
      for (int i = 0; i < typePtrs.length; i++) {
        final off = elf.mapVATR(typePtrs[i]);
        if (off == 0) continue;
        final data = elf.file.ptrAt(off);
        final bits = elf.file.u32At(off + ps);
        final e = Il2CppTypeEntry(data, bits);
        list[i] = e;
        _typeByPtr[typePtrs[i]] = e;
      }
      types = list;
    }

    // codeGenModules (v24.2+)
    if (version >= 24.2 && cgmPtr != 0) {
      final modPtrs = _readVaArray(cgmPtr, cgmCount);
      for (int k = 0; k < modPtrs.length; k++) {
        final off = elf.mapVATR(modPtrs[k]);
        if (off == 0) continue;
        final namePtr = elf.file.ptrAt(off);
        final nameOff = elf.mapVATR(namePtr);
        if (nameOff == 0) continue;
        final name = elf.file.readCString(nameOff, 256);
        final count = elf.file.ptrAt(off + ps);
        final ptrsVa = elf.file.ptrAt(off + ps * 2);
        Uint32List raw = Uint32List(0);
        if (count > 0 && count < 4000000 && ptrsVa != 0) {
          raw = _readVaArray(ptrsVa, count);
        }
        if (name.isNotEmpty) {
          codeGenModules[name] = CodeGenModule(name, count, raw);
        }
      }
    } else {
      // v24.0-24.1: methodPointers global (feld methodPointersCount di slot 0/1)
      final base = elf.mapVATR(codeRegAddr);
      final mpCount = elf.file.ptrAt(base);
      final mpPtr = elf.file.ptrAt(base + ps);
      globalMethodPointers = _readVaArray(mpPtr, mpCount);
    }

    _loadMethodSpecs();
    hasRegistrations = true;
  }

  void _loadMethodSpecs() {
    try {
      if (methodSpecsCount <= 0 || methodSpecsCount > 4000000) return;
      if (genericMethodTableCount <= 0 || genericMethodTableCount > 4000000) return;
      final ps = ptrSize;
      final specOff = elf.mapVATR(methodSpecsPtr);
      final tableOff = elf.mapVATR(genericMethodTablePtr);
      if (specOff == 0 || tableOff == 0) return;
      final tableStride = (version >= 27.1 || version == 24.5) ? 16 : 12;
      final n = genericMethodTableCount;
      _specPtrs = Uint32List(methodSpecsCount);
      specMd = Int32List(methodSpecsCount);
      specClass = Int32List(methodSpecsCount);
      specMethod = Int32List(methodSpecsCount);
      for (int i = 0; i < n; i++) {
        final b = tableOff + i * tableStride;
        final gmi = elf.file.u32At(b);
        final mi = elf.file.u32At(b + 4);
        if (gmi < 0 || gmi >= methodSpecsCount) continue;
        if (mi < genericMethodPointers.length) {
          _specPtrs[gmi] = genericMethodPointers[mi];
        }
        final sb = specOff + gmi * 12;
        final mdIdx = elf.file.u32At(sb);
        final classIdx = elf.file.u32At(sb + 4);
        final methIdx = elf.file.u32At(sb + 8);
        specMd[gmi] = mdIdx;
        specClass[gmi] = classIdx;
        specMethod[gmi] = methIdx;
        if (mdIdx < 0 || mdIdx >= meta.methodDefCount) continue;
        methodDefinitionMethodSpecs.putIfAbsent(mdIdx, () => [])..add(gmi);
      }
    } catch (_) {}
  }

  int methodSpecPointer(int specIndex) =>
      (specIndex >= 0 && specIndex < _specPtrs.length) ? _specPtrs[specIndex] : 0;

  // ---------------------------------------------------------------- akses dumper

  Il2CppTypeEntry? getTypeByPtr(int pointer) => _typeByPtr[pointer];

  /// Pointer method (VA) untuk methodDef index [methodIndex] di image [imageName].
  int getMethodPointer(String imageName, int methodIndex) {
    final rid = meta.mdToken[methodIndex] & 0x00FFFFFF;
    if (version >= 24.2) {
      final mod = codeGenModules[imageName];
      if (mod == null) return 0;
      if (rid <= 0 || rid > mod.methodPointerCount) return 0;
      return mod.methodPointers[rid - 1];
    }
    final mi = meta.mdMethodIndex[methodIndex];
    if (mi >= 0 && mi < globalMethodPointers.length) {
      return globalMethodPointers[mi];
    }
    return 0;
  }

  /// Offset field di class (dump.cs "// 0x..").
  int getFieldOffsetFromIndex(int typeIndex, int fieldIndexInType, int fieldIndex, bool isValueType, bool isStatic) {
    try {
      int offset = -1;
      if (typeIndex < fieldOffsetPtrs.length) {
        final ptr = fieldOffsetPtrs[typeIndex];
        if (ptr > 0) {
          final off = elf.mapVATR(ptr) + 4 * fieldIndexInType;
          offset = elf.file.u32At(off);
        }
      }
      if (offset > 0 && isValueType && !isStatic) {
        offset -= elf.is32 ? 8 : 16;
      }
      return offset;
    } catch (_) {
      return -1;
    }
  }

  int getRVA(int pointer) => pointer;
}
